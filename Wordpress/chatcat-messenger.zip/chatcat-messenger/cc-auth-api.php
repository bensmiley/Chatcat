<?php
/**
 * Created by PhpStorm.
 * User: benjaminsmiley-andrews
 * Date: 23/09/2014
 * Time: 15:55
 */
require_once "CCAuth.php";

// Allow AJAX calls
header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Headers: Origin, X-Requested-With, Content-Type, Accept");

// Get the current user
if ( !defined('__DIR__') ) define('__DIR__', dirname(__FILE__));
$path = explode('wp-content',__DIR__);
include_once($path[0].'wp-load.php');
//include_once($path[0].'option.php');

global $current_user;

// Is the user logged in?
if($current_user->ID > 0) {
    // Get the API key from the settings
    $api_key = get_option('cc_options');

    // Get the user's description
    $description = get_the_author_meta( 'description', $current_user->ID, $_SERVER['HTTP_HOST']);

    // Create a new Auth instance
    $auth = new CCAuth ($current_user->ID, $api_key['api_key'], '');

    // Authenticate the user
    $auth->authUser($current_user->display_name, $description, null, null, null, null, array());

}
else {
    CCAuth::logout();
}


