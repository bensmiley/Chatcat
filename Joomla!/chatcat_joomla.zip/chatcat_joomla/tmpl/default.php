<?php defined('_JEXEC') or die; ?>
<div ng-app="myApp" ><ng-include data-src="baseURL+ 'chatcat.html'" ng-controller="AppController"></ng-include></div>
