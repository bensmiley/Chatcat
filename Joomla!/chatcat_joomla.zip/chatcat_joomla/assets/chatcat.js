var ccProtocol = (("https:" == document.location.protocol) ? "https://" : "http://");

document.write(decodeURI("%3Clink rel='stylesheet' href='" + ccProtocol + "chatcat.firebaseapp.com/css/_/cc_styles.min.css' %3E%3C/link%3E"));
document.write(decodeURI("%3Cscript src='" + ccProtocol + "chatcat.firebaseapp.com/js/all.min.js' type='text/javascript'%3E%3C/script%3E"));

	
// document.write(decodeURI("%3Clink rel='stylesheet' href='" + ccProtocol + "chatcat/dist/css/_/cc_styles.min.css' %3E%3C/link%3E"));
// document.write(decodeURI("%3Cscript src='" + ccProtocol + "chatcat/dist/js/all.js' type='text/javascript'%3E%3C/script%3E"));
